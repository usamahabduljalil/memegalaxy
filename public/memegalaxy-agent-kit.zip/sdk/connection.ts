import { Client,type Room } from 'colyseus.js';
import { decodeObservation,type GalaxyFrame } from '../shared/galaxy/wire';
import type { Action,Observation } from '../shared/galaxy/types';
export type ArenaConnection={send:(action:Action)=>void;close:()=>Promise<void>};
export async function connectArena(server:string,ticket:{roomId:string;token:string},callbacks:{frame:(o:Observation)=>void;identity:(v:{id:string;seq:number})=>void;state?:(message:string)=>void;closed?:(message:string)=>void;result?:(result:any[])=>void}):Promise<ArenaConnection>{
 const client=new Client(server.replace(/^http/,'ws'));let room:Room,closed=false,reconnecting=false,observation:Observation|undefined;
 const attach=(r:Room)=>{room=r;observation=undefined;r.onMessage('identity',callbacks.identity);r.onMessage('frame',(frame:GalaxyFrame|string)=>{observation=decodeObservation(frame,observation);callbacks.frame(observation);});r.onMessage('result',r=>callbacks.result?.(r));r.onMessage('invalid',(v:{message:string})=>{closed=true;callbacks.closed?.(v.message);});r.onError((_code,message)=>callbacks.state?.(message??'Connection interrupted'));
 r.onLeave(async(code)=>{if(closed)return;if(code===4000||code===4003){closed=true;callbacks.closed?.('This room session ended.');return;}if(reconnecting)return;reconnecting=true;callbacks.state?.('Reconnecting — your cells remain vulnerable…');const deadline=Date.now()+19000;while(!closed&&Date.now()<deadline){try{const next=await client.reconnect(r.reconnectionToken);if(closed){await next.leave();return;}attach(next);callbacks.state?.('');reconnecting=false;return;}catch{await new Promise(resolve=>setTimeout(resolve,750));}}reconnecting=false;if(!closed)callbacks.closed?.('Unable to reconnect within twenty seconds.');});};
 attach(await client.joinById(ticket.roomId,{token:ticket.token}));return {send:a=>{if(!closed&&!reconnecting&&room.connection.isOpen)room.send('action',a);},close:async()=>{closed=true;await room.leave();}};
}
